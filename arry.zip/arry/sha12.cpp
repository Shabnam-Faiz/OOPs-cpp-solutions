#include <iostream>
using namespace std;

int main() {
    int arr1[] = {5, 1, 4, 2, 8};
    int arr2[] = {5, 1, 4, 2, 8};
    int n = 5;

    // Bubble Sort
    int bubble_comparisons = 0;
    for (int i = 0; i < n-1; i++) {
        for (int j = 0; j < n-i-1; j++) {
            bubble_comparisons++;
            if (arr1[j] > arr1[j+1]) {
                int temp = arr1[j];
                arr1[j] = arr1[j+1];
                arr1[j+1] = temp;
            }
        }
    }

    cout << "Bubble Sort - Sorted List: ";
    for (int i = 0; i < n; i++) cout << arr1[i] << " ";
    cout << "\nTotal Comparisons: " << bubble_comparisons << endl;

    // Selection Sort
    int selection_comparisons = 0;
    for (int i = 0; i < n-1; i++) {
        int minIndex = i;
        for (int j = i+1; j < n; j++) {
            selection_comparisons++;
            if (arr2[j] < arr2[minIndex]) {
                minIndex = j;
            }
        }
        int temp = arr2[i];
        arr2[i] = arr2[minIndex];
        arr2[minIndex] = temp;
    }

    cout << "Selection Sort - Sorted List: ";
    for (int i = 0; i < n; i++) cout << arr2[i] << " ";
    cout << "\nTotal Comparisons: " << selection_comparisons << endl;

    return 0;
}
